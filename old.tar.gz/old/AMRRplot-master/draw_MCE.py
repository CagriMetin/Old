from mpl_toolkits.mplot3d import Axes3D
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib import pyplot
from matplotlib import cm
import numpy as np

def Smagnetic(Temp,H):
	S_mag = 0 #initialize Magnetic entropy
	R_u = 8.314 #Universal Gas Constant [J/mol-K]
	g_j = 2.0 #Spectroscopic splitting factor
	mu_B = 9.270154e-24 #Bohr magneton [Joule/Tesla]
	K = 1.380622e-23 #Boltzmann constant [Joule/Kelvin]
	Tcurie = 293.0 #Curie temperature [K]
	J = 3.5 #Total angular momentum
	Mm = 0.15725 #Molar mass [kg/mol]
	URF_brill = 0.8
	count = 0
	X=1.0 #Assume X starts 1
	#First iter before while loop
	A1= (2*J+1)/(2*J)
	A2 = 1/(2*J)
	B_j = A1*np.power(np.tanh(A1*X),-1)-A2*np.power(np.tanh(A2*X),-1)
	x_dummy=(g_j*mu_B*H*J)/(K*Temp)+(3*Tcurie*B_j*J)/(Temp*(J+1))
	error=abs((X-x_dummy)/X*100)
	epsilon=1e-4
    
	while error >= epsilon:
		#print ('Number of iter: '+str(count))
		A1=0.0
		A2=0.0
		x_dummy=0.0
		A1= (2*J+1)/(2*J)
		A2 = 1/(2*J)
		B_j = A1*np.power(np.tanh(A1*X),-1)-A2*np.power(np.tanh(A2*X),-1)
		x_dummy=(g_j*mu_B*H*J)/(K*Temp)+(3*Tcurie*B_j*J)/(Temp*(J+1))
		error=0
		error=abs((X-x_dummy)/X*100)
		if error < 0:
			error=-error
		if error >= epsilon:
			count+=1
			X=x_dummy*URF_brill+X*(1-URF_brill)
		#print ('X: '+str(X))
		#print ('Bj: '+str(B_j))
		#print ('')
		#print ('X: '+str(X))
	#print ('Bj: '+str(B_j))
	#print ('Magnetic Entropy: '+str(S_mag))
	#print ('')
	S_mag=(R_u)*(np.log(np.sinh(A1*X)/np.sinh(A2*X))-X*B_j)/Mm #Dimensions [J/mol.K]
	return S_mag

def Slattice(Temp):
	S_lat = 0 #initialize Lattice entropy
	R_u = 8.314 #Universal Gas Constant [J/mol-K]
	Tdebye = 184.0 #Debye tepperature [K]
	Mm = 0.15725 #Molar mass [kg/mol]
	#Numerical integration for last term
	delta=float(Tdebye/Temp)/100 #Step size
	mySum=0
	for i in range(1,101):
		x=delta*i
		x0=delta*(i-1)
		if i == 1:
			mySum=0
		else:
			mySum+=((np.power(x,3)/(np.exp(x)-1))+(np.power(x0,3)/(np.exp(x0)-1)))*delta/2
	S_lat=(R_u)*((-3*np.log(1-np.exp(-Tdebye/Temp)))+12*np.power(Temp/Tdebye,3)*mySum)/Mm #Dimensions [J/mol.K]
	return S_lat
    
def Sabs(Temp,H):
	return Smagnetic(Temp,H) + Slattice(Temp)
def C(Temp,H):
	delta = 0.1 #Step size for central difference of 4th order
	s2dt = Smagnetic(Temp+2*delta,H) + Slattice(Temp+2*delta) #Two times delta forward
	sdt = Smagnetic(Temp+delta,H) + Slattice(Temp+delta)  #One times delta forward
	s_2dt = Smagnetic(Temp-2*delta,H) + Slattice(Temp-2*delta) #Two times delta backward
	s_dt = Smagnetic(Temp-delta,H) + Slattice(Temp-delta) #One times delta backward
	#4th order central diffrence
	dsdt=(-s2dt+8*sdt-8*s_dt+s_2dt)/(12*delta)
	cp=dsdt*Temp
	return cp
	print ('Cp :'+str(cp))

def deltaSmag(Temp, H):
	refSmag = Smagnetic(Temp,0.0001)
	deltaSmag = -Smagnetic(Temp,H)+refSmag
	return deltaSmag

def deltaT(Temp, H):
	deltaTad = deltaSmag(Temp,H)*Temp/C(Temp,H)
	return deltaTad 

def drawSmag():
        nx = 51
	T = np.linspace(100,400,nx)
        H = np.linspace(0.001, 10, nx)
        u = np.ones((nx,nx))

	for j in range(0,nx):
		for i in range(0,nx):
			u[i,j] = deltaSmag(T[j],H[i])

	fig = pyplot.figure(figsize=(11,7), dpi = 100)
	ax = fig.gca(projection='3d')
	X,Y = np.meshgrid(T,H)
	surf = ax.plot_surface(X,Y,u,rstride=1, cstride=1, cmap=cm.coolwarm,
			linewidth=0, antialiased=False)

	ax.set_xlabel(r'$Temperature (K)$')
        ax.set_ylabel(r'$Magnetic Field (Tesla)$')
        ax.set_zlabel(r'$\Delta S_m (J/Kmol)$')

	ax.zaxis.set_major_locator(LinearLocator(10))
	ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

	fig.colorbar(surf, shrink=0.5, aspect=5)


	pyplot.show()



def drawC():
        nx = 51
	T = np.linspace(100,400,nx)
        H = np.linspace(0.001, 10, nx)
        u = np.ones((nx,nx))

	for j in range(0,nx):
		for i in range(0,nx):
			u[i,j] = C(T[j],H[i])

	fig = pyplot.figure(figsize=(11,7), dpi = 100)
	ax = fig.gca(projection='3d')
	X,Y = np.meshgrid(T,H)
	surf = ax.plot_surface(X,Y,u,rstride=1, cstride=1, cmap=cm.coolwarm,
			linewidth=0, antialiased=False)

	ax.set_xlabel(r'$Temperature (K)$')
        ax.set_ylabel(r'$Magnetic Field (Tesla)$')
        ax.set_zlabel(r'$Heat Capacity (J/mol)$')

	ax.zaxis.set_major_locator(LinearLocator(10))
	ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

	fig.colorbar(surf, shrink=0.5, aspect=5)


	pyplot.show()


def drawDeltaT():
        nx = 51
	T = np.linspace(100,400,nx)
        H = np.linspace(0.001, 10, nx)
        u = np.ones((nx,nx))

	for j in range(0,nx):
		for i in range(0,nx):
			u[i,j] = deltaT(T[j],H[i])

	fig = pyplot.figure(figsize=(11,7), dpi = 100)
	ax = fig.gca(projection='3d')
	X,Y = np.meshgrid(T,H)
	surf = ax.plot_surface(X,Y,u,rstride=1, cstride=1, cmap=cm.coolwarm,
			linewidth=0, antialiased=False)
 
	ax.set_xlabel(r'$Temperature (K)$')
	ax.set_ylabel(r'$Magnetic Field (Tesla)$')
        ax.set_zlabel(r'$\Delta T (K)$')

	ax.zaxis.set_major_locator(LinearLocator(10))
	ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

	fig.colorbar(surf, shrink=0.5, aspect=5)

	pyplot.show()

#drawSmag()
#drawC()
drawDeltaT()
